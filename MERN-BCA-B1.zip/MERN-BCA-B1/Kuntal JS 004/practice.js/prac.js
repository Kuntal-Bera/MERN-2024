const arr =[45,69,54,21,98,78,61,65,78];
for(let x in arr){
    console.log(arr[x]);
}
let arr2 = [{id:1, name:'Manish'},{id:2, name:'Kuntal'},{id:3, name:'Suman'}];
for(let item  of arr2){
    if(item.id ===2)
        console.log(item);
    

}