
// module.exports = mongoose.model('users', userModel);
const express = require('express');
const router = express.Router();
const ApiController = require('../controller/api-controller');
const apicontroller = new ApiController.apicontroller();

router.get('/user/list', apicontroller.getUser);
router.post('/user/add', apicontroller.addUser);

router.get('/user/info/:id', apicontroller.getSingleData);
router.get('/user/update', apicontroller.updateUserData);
router.get('/user/delete/:id', apicontroller.deleteUser)

module.exports = {
    route: router
}

