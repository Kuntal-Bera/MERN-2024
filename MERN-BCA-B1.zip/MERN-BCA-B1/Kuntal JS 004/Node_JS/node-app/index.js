
// const http = require('http');
// const dotenv = require('dotenv');

// dotenv.config();
// console.log(dotenv.config());
// const PORT = process.env.PORT

// console.log('Server running on port 8080');

// let server = http.createServer(function(req,res){
//     res.writeHead(200, {'Content-Type': 'application/json'});
//     let obj = [{name: 'Manish Giri',age: 22},
//         {name: 'Kuntal Bera',age: 21},
//         {name: 'Suman BAjani',age:20}]
    
//     res.end(JSON.stringify(obj));
// })
// server.listen(PORT, console.log(`Server running on port ${PORT}`));


/*const http = require('http');
const dotenv = require('dotenv');

//load server
 dotenv.config();
 console.log(dotenv.config());
const PORT = process.env.PORT
let server = http.createServer(function(req,res){
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.write('Hello World!');
    res.end();
})
server.listen(PORT, console.log(`Server running on port ${PORT}`));*/


/*
const http = require('http');
const dotenv = require('dotenv');
const express = require('express');
const app = express();
dotenv.config();
const PORT = process.env.PORT   
app.get('/user', function(req,res){
    res.send({
        "massage":"Hello"
    })
})
let server = http.createServer(app);
 //Start server  on the specified port.
server.listen(PORT, function(err){
    if (err) throw err;
     console.log(`Server running on port ${PORT}`)
    });*/


   /* const http = require('http');
const dotenv = require('dotenv');
const express = require('express');

const app = express();
dotenv.config();
const PORT = process.env.PORT

let obj = [{name: 'Manish Giri',age: 22},
    {name: 'Kuntal Bera',age: 21},
    {name: 'Suman BAjani',age:20}]

    let server = http.createServer(app);

app.get('/user',function(req,res){
    res.send(obj)
})

server.listen(PORT, function(err){
    if (err) throw err;
    console.log(`Server running on port ${PORT}`);
});*/

const http = require('http');
const dotenv = require('dotenv');
const path = require('path');
const express = require('express');
const app = express();
dotenv.config();


require('./config/database')();
const PORT = process.env.PORT

const router = require('./routes/api-routes');
const bodyParser = require('body-parser');


let server = http.createServer(app);
app.use(express.static(path.join(__dirname,"public")));

app.use(
    bodyParser.urlencoded({ extended: true })
);

app.use(bodyParser.json());


app.use('/api',router.route);

server.listen(PORT, function(err){
    if (err) throw err;
    console.log(`Server running on port ${PORT}`);
});