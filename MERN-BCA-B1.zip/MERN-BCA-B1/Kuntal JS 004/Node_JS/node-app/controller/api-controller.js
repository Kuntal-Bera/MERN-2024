const userModel = require ("../model/user-model");


class apicontroller {
    constructor() {}
    getUser = async (req, res) => {
        try {
            let userData = await userModel.find({ "active_status": true, delete_status: false });
            let userSingleData = await userModel.findOne();
            console.log(userSingleData, 'userSingleData')

            res.send({
                "message": "Data fetched successfully",
                data: userData
            })
        }

    catch(err){
    res.send({
        message: "Error fetching data",
        "error": err.massege,
    });
    }

    }

    addUser = async (req, res) => {
        try {
            // console.log(req.body,'req.body')
            let User = new userModel();
            req.body.password = User.generateHash(req.body.password);

            req.body.phone = User.generateHash(req.body.phone);
            
            let userData = new userModel(req.body);
            let saveData = await userData.save();

            res.send({
                "message": "Data added successfully",
                "data": saveData
            })
        } catch (err) {
            res.send({
                "message": "Error",
                data: err
            })
        }
    }
    getSingleData = async (req, res) => {
    try{
        console.log(req.params,'==req.params==');
        let userSingleData = await userModel.findOne({_id: req.params.id});

        res.send({
            "massage": "Data retrive successfully!",
            data : userSingleData
        })
        // console.log(userSingleData);
    }
    catch(err){
        res.send({
            "massage": "eror",
            error: err
        });

    }
}

    updateUserData = async (req, res) => {
        try{
            let anotherData = await userModel.findOne({name: "Manish Giri"});
            anotherData.name = "Monosha";
            await anotherData.save();
            // let updateData = await userModel.findByIdAndUpdate(req.body.id, req.body);
            // let userSingleData = await userModel.findOne({_id: req.body.id});

            res.send({
                "message": "Data updated successfully!",
                data : anotherData
            })
        }
            catch (err){
                res.send({
                    "message": "Error........",
                    data: err
                })
            }
       
}
    deleteUser = async (req, res) => {
        try{
            // let deleteData = await userModel.findByIdAndDelete(req.params.id);

            let userDirectData = await userModel.findByIdAndDelete({email: 'manishgiri69@gmail.com'});

            res.send({
                "message": "Data deleted successfully!",
                data : userDirectData
            })
            console.log(userDirectData);
        }
        catch (err){
            res.send({
                "message": "Error........",
                data: err
            })
        }
    
}
}
module.exports = {
    apicontroller
}
